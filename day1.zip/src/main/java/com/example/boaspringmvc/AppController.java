package com.example.boaspringmvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/mainapp")
public class AppController {

	@Autowired
	private UserService service;

	@RequestMapping(value = "/login", method = RequestMethod.GET)

	public String login(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public String loginVALID(@ModelAttribute User user) {

		 

		if (service.loginValid(user)) {
			return "Login Success";
		}

		return "login Failed";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)

	public String register() {
		return "register";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	@ResponseBody
	public String registerUser(@RequestParam("uname") String name, @RequestParam("pwd") String pwd,
			@RequestParam("email") String email, @RequestParam("city") String city) {

		User user = new User(name, pwd, email, city);

		service.addUser(user);

		return "user added";
	}

}
