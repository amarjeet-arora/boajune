package com.example.boaspringmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoaSpringMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaSpringMvcApplication.class, args);
	}

}
