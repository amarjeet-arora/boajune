package com.example.boaspringmvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	private List<User> lst= new ArrayList<User>();
	
	public boolean loginValid(User login) {
		if(login.getUname().equals("admin")&& login.getPass().equals("manager")) {
			
			return true;
		}
		return false;
	}
	
	public void addUser(User user){
		lst.add(user);
		System.out.println(lst);
	}

}
