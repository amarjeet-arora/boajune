package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;
 public class BankService {
	 
	private InterestCalculator ic;
	

	public double service(double amount) {
		return ic.calculate(amount);
	}


	public BankService(InterestCalculator ic) {
		super();
		this.ic = ic;
	}
	

}
