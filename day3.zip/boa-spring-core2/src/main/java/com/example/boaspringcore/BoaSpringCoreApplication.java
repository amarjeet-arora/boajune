package com.example.boaspringcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoaSpringCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaSpringCoreApplication.class, args);
	}

}
