package com.model;

public interface InterestCalculator {

	public double calculate(double amount);
}
