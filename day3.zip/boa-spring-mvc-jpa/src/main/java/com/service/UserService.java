package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserRepo;
import com.model.User;

@Service
public class UserService {
	@Autowired
	private UserRepo repo;
	
	private List<User> lst= new ArrayList<User>();
	
	public boolean loginValid(User login) {
		if(login.getUname().equals("admin")&& login.getPass().equals("manager")) {
			
			return true;
		}
		return false;
	}
	
	public void addUser(User user){
		//lst.add(user);
		repo.save(user);
		System.out.println(lst);
	}
	public List<User> loadUsers(){
		
		List<User> lst2=(List)repo.findAll();
		
		return lst2;
	}
	public boolean findUser(String name) {
		
		Optional found=  repo.findById(name);
		if(found.isPresent()) {
			return true;
		}
		return false;
	}

	
	public void deleteUser(String name) {
		 repo.deleteById(name);
		
	}
	
	
	
public void updateUser(String name,User user) {
	
	repo.updateEmailByUname(user.getEmail(),name );
	
}
	
	
	
}
