package com.java.rest;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.model.Employee;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class WebAppTest {
	@LocalServerPort
	int randomPort;
	
	@Test
	public void testGetEmployee() throws URISyntaxException {
		RestTemplate restTemplate= new RestTemplate();
		
		String baseURL="http://localhost:"+randomPort+"/loademp/";
		URI uri= new URI(baseURL);
		HttpHeaders headers= new HttpHeaders();
		headers.set("X-COM-LOCATION", "USA");
		HttpEntity<Employee> entity= new HttpEntity<>(null,headers);
		try {
			restTemplate.exchange(uri, HttpMethod.GET,entity,String.class);
			Assert.fail();
		}catch (HttpClientErrorException e) {
			Assert.assertEquals(400, e.getRawStatusCode());
			 
		}
	}
	@Test
	public void testAdd() throws URISyntaxException {
RestTemplate restTemplate= new RestTemplate();
		
		String baseURL="http://localhost:"+randomPort+"/adduser/";
		URI uri= new URI(baseURL);
		Employee emp= new Employee("admin",4,"aa@mail.com");
		
		HttpHeaders headers= new HttpHeaders();
		headers.set("X-COM-PERSIST", "true");
		
		HttpEntity<Employee> entity= new HttpEntity<>(emp,headers);
		 
		
		ResponseEntity<String> re= restTemplate.postForEntity(uri, entity, String.class);
		Assert.assertEquals(200, re.getStatusCodeValue());
	}
	
	
	
	

}
