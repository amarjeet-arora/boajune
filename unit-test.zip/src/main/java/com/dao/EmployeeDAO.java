package com.dao;

import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.model.Employees;

@Repository
public class EmployeeDAO {
	
	private static Employees list= new Employees();
	
	static {
		list.getEmplist().add(new Employee("admin", 1, "admin@mail.com"));
		list.getEmplist().add(new Employee("manager", 2, "manager@mail.com"));

		list.getEmplist().add(new Employee("QA", 3, "QA@mail.com"));

	}
	public Employees getEmployees() {
		return list;
	}
	public void addEmployee(Employee employee) {
		list.getEmplist().add(employee);
	}

}
