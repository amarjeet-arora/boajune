package com.java.employees.controllers;

 import javax.validation.ValidationException;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.java.employees.model.Employee;

@ExtendWith(SpringExtension.class)
@WebMvcTest
public class AnotherControllerTest {
	@Autowired
	EmployeeController controller;
	
	@Test
	public void testCreateAndDelete() {
		
		Employee emp= new Employee("admin", "manager");
		Employee er= controller.create(emp);
		
		Iterable<Employee> employees= controller.read();
		Assertions.assertThat(employees).first().hasFieldOrPropertyWithValue("firstName", "admin");
		
		controller.delete(er.getId());
		Assertions.assertThat(controller.read()).isEmpty();
	}
	@Test
	public void errorExceptionHandle() {
		Assertions.assertThatExceptionOfType(ValidationException.class)
		.isThrownBy(() -> controller.somethingIsWrong());
	}

}
