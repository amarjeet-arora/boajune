package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserRepo;
import com.model.User;

@Service
public class UserService {
	@Autowired
	private UserRepo repo;
	
	private List<User> lst= new ArrayList<User>();
	
	public boolean loginValid(User login) {
		if(login.getUname().equals("admin")&& login.getPass().equals("manager")) {
			
			return true;
		}
		return false;
	}
	
	public void addUser(User user){
		//lst.add(user);
		repo.save(user);
		System.out.println(lst);
	}
	public List<User> loadUsers(){
		return lst;
	}
	public boolean findUser(String name) {
		for(User usr:lst) {
			if(usr.getUname().equals(name)) {
				System.out.println(usr.getEmail());
				return true;
			}
		}
		return false;
	}

	
	public boolean deleteUser(String name) {
		for(User usr:lst) {
			if(usr.getUname().equals(name)) {
			lst.remove(usr);
				return true;
			}
		}
		return false;
	}
	
	
	
public void updateUser(String name,User user) {
	
	
}
	
	
	
}
